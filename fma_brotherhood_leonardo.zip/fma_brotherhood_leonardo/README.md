Fullmetal Alchemist: Brotherhood - Projeto Front-End
Aluno: Leonardo dos santos da silva
Faculdade: UniFECAF
Disciplina: Web Programming for Front End

Arquivos:
- index.html
- styles.css
- script.js
- Parte Teórica: Parte_Teorica_FMA_Leonardo_UniFECAF.pdf

Como testar:
1. Abra index.html no navegador.
2. A página consome Jikan API: https://api.jikan.moe/v4/anime/5114/characters
3. Use busca por personagem ou navegue pelos resultados.